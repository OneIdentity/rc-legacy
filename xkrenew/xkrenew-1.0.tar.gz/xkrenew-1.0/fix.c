/* $Id: fix.c,v 1.1.1.1 2005/03/19 17:05:41 d Exp $ */
/* David Leonard, 2003. Public domain. */

#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#include <X11/CoreP.h>
#include <X11/Xaw/Label.h>

/*
 * X11R6.4 contains builtin-pixmap support. Internally, the
 * label widget supports Pixmaps, but since the wrong resource
 * type was associated with it (ie XtRBitmap) the string converter
 * won't bother checking for pixmaps. This is a bug in Xaw in my view.
 *
 * This function 'patches' the label class so that the bitmap
 * resource is of type pixmap.
 */
void FixXaw()
{
	int i;

	CoreClassPart *c = (CoreClassPart *)labelWidgetClass;
	XtResource *r = c->resources;
	for (i = 0; i < c->num_resources; i++)
	    if (r[i].resource_name == XtNbitmap) {
		r[i].resource_type = XtRPixmap;
		break;
	    }
}

