#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/Xmu/Editres.h>

#include <X11/Xaw/Label.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/Sme.h>
#include <X11/Xaw/SmeBSB.h>

#include "fix.h"
#include "krenew.h"

static void Quit(Widget, XEvent *, String *, Cardinal *);
static void Renew(Widget, XEvent *, String *, Cardinal *);

static void QuitCallback(Widget, XtPointer, XtPointer);
static void RenewCallback(Widget, XtPointer, XtPointer);

#if !USE_ITIMER
static void TimerProc(XtPointer, XtIntervalId *);
#else /* itimer */
# include <signal.h>
# include <sys/time.h>
static void SignalProc(XtPointer, XtSignalId *);
static void RestartItimer(void);
static XtSignalId itimer_signal_id;
#endif

static void Update(void);

static char version[] = "xkrenew 1.0";

static String fallback_resources[] = {
	"?.width: 36",
	"?.height: 36", 
	"?.allowShellResize: true",
	"?.ticketLabel.bitmap: xpm:ticket.xpm",
	"?.ticketLabel.background: white",
	"?.noticketLabel.bitmap: xpm:noticket.xpm",
	"?.noticketLabel.background: white",
	"?.menuButton.internalWidth: 1",
	"?.menuButton.internalHeight: 1",
	"*.saveUnder: true",
	NULL
};

static unsigned long interval = 1000 * DEFAULT_CHECK_INTERVAL;
static Boolean last_was_valid = FALSE;

static XrmOptionDescRec options[] = {
	/* { "-flag", ".xkrenew.flag", XrmoptionNoArg, (XtPointer)"true" }, */
	/* { "-option", ".xkrenew.option", XrmoptionSepArg }, */
};

static XtActionsRec actions[] = {
	{ "quit",	Quit },
	{ "renew",	Renew }
};

static XtAppContext appContext;
static Widget toplevel;
static Widget menuButton;
static Widget ticketLabel;
static Widget noticketLabel;
static Widget menu;

Boolean debug = FALSE;
extern String renewCommand;

void
set_menu_button_bitmap(Widget label)
{
    Arg arg;
    Pixmap pixmap;

    XtSetArg(arg, XtNbitmap, &pixmap);
    XtGetValues(label, &arg, 1);
    XtSetArg(arg, XtNbitmap, pixmap);
    XtSetValues(menuButton, &arg, 1);
}

void
set_menu_button_tip(String tip)
{
    Arg arg;

    XtSetArg(arg, XtNtip, tip);
    XtSetValues(menuButton, &arg, 1);
}

int
main(argc, argv)
	int argc;
	char *argv[];
{
	Display *display;
	Atom wm_delete_window;
	Widget entry;

	FixXaw();

	toplevel = XtOpenApplication(
		&appContext,			/* app_context_return */
		"XKrenew",			/* application_class */
		options, XtNumber(options),	/* options, num_options */
		&argc, argv,			/* argc, argv */
		fallback_resources,		/* fallback_resources */
		sessionShellWidgetClass,	/* widget_class */
		NULL, 0				/* args, num_args */
	);

	XtAppAddActions(appContext, actions, XtNumber(actions));

	ticketLabel = XtCreateWidget("ticketLabel", 
		labelWidgetClass, toplevel, NULL, 0);

	noticketLabel = XtCreateWidget("noticketLabel", 
		labelWidgetClass, toplevel, NULL, 0);

	menuButton = XtCreateManagedWidget("menuButton",
		menuButtonWidgetClass, toplevel, NULL, 0);
	XawTipEnable(menuButton);

	menu = XtCreatePopupShell("menu", simpleMenuWidgetClass,
		menuButton, NULL, 0);

	entry = XtCreateManagedWidget("renew", smeBSBObjectClass,
		menu, NULL, 0);
	XtAddCallback(entry, XtNcallback, RenewCallback, NULL);

	entry = XtCreateManagedWidget("quit", smeBSBObjectClass,
		menu, NULL, 0);
	XtAddCallback(entry, XtNcallback, QuitCallback, NULL);

	XtRealizeWidget(toplevel);

	/* Translate window manager close request into quit */
	display = XtDisplay(toplevel);
	wm_delete_window = XInternAtom(display, "WM_DELETE_WINDOW", False);
	XSetWMProtocols(display, XtWindow(toplevel), &wm_delete_window, 1);
	XtOverrideTranslations(toplevel,
	    XtParseTranslationTable("<Message>WM_PROTOCOLS:quit()"));

	/* Enable editres(1) */
	XtAddEventHandler(toplevel, 0, True, _XEditResCheckMessages, NULL);

	last_was_valid = FALSE;
	set_menu_button_bitmap(noticketLabel);

	/* Set the right labels now */
	Update();

	/* Arrange for Update() to be called periodically */
#if !USE_ITIMER
	XtAppAddTimeOut(appContext, interval, TimerProc, NULL);
#else
	itimer_signal_id = XtAppAddSignal(appContext, SignalProc, NULL);
	RestartItimer();
#endif

	XtAppMainLoop(appContext);
	exit(0);
}

static void
Update()
{
	Boolean now_valid;

	now_valid = KIsTicketValid(appContext);
	if (now_valid != last_was_valid) {
	    set_menu_button_bitmap(now_valid ? ticketLabel : noticketLabel);
	    last_was_valid = now_valid;
	}

	set_menu_button_tip(KTicketGetInfo(appContext));
}

#if !USE_ITIMER
static void
TimerProc(XtPointer closure, XtIntervalId *id)
{
	if (debug)
		printf("TimerProc(%lu) *id=%d\n", interval, *id);
	Update();
	XtAppAddTimeOut(appContext, interval, TimerProc, closure);
}
#endif

#if USE_ITIMER
static void
SignalProc(XtPointer closure, XtSignalId *id)
{
	if (debug)
		printf("SignalProc(%lu) *id=%d\n", interval, *id);
	Update();
	RestartItimer();
}

static void
sigalrm(int sig)
{
	if (debug) write(2, "sigalrm()\n", 10);
	XtNoticeSignal(itimer_signal_id);
}

static void
RestartItimer()
{
	struct itimerval val;

	if (signal(SIGALRM, sigalrm) == SIG_ERR) {
		perror("signal");
		XtAppError(appContext, "signal");
	}
	val.it_value.tv_usec = (interval % 1000) * 1000;
	val.it_value.tv_sec = interval / 1000;
	timerclear(&val.it_interval);
	if (setitimer(ITIMER_REAL, &val, NULL) == -1) {
		perror("setitimer");
		XtAppError(appContext, "setitimer");
	}
	if (debug) {
		printf("RestartItimer { interval %u.%06u, value %u.%06u }\n",
		    val.it_interval.tv_sec, val.it_interval.tv_usec,
		    val.it_value.tv_sec, val.it_value.tv_usec);
	}
}
#endif

static void
Quit(Widget w, XEvent *e, String *params, Cardinal *num_params)
{
	XtDestroyWidget(toplevel);
	XtAppSetExitFlag(appContext);
}

static void
Renew(Widget w, XEvent *e, String *params, Cardinal *num_params)
{
	KRenewTicket(appContext);
}

static void
QuitCallback(Widget w, XtPointer closure, XtPointer call_data)
{
	Cardinal zero = 0;
	Quit(w, NULL, NULL, &zero);
}

static void
RenewCallback(Widget w, XtPointer closure, XtPointer call_data)
{
	Cardinal zero = 0;
	Renew(w, NULL, NULL, &zero);
	Update();
}
