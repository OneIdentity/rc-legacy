#include <X11/Intrinsic.h>
#include <X11/Xmu/Xmu.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <krb5.h>
#include "krenew.h"

extern Boolean debug;
String renewCommand = "/usr/bin/kinit -R";

static void
warn(XtAppContext appContext, String msg, krb5_error_code error)
{
	char buffer[1024];
	extern int errno;

	if (debug) {
	    XmuSnprintf(buffer, sizeof buffer, "%s: %s", 
		msg, strerror(errno));
	    XtAppWarning(appContext, buffer);
	}
}

static unsigned int renew_remaining = 1*60*60; /* renew when 1 hour left */
static char credinfo[2048];

Boolean 
KIsTicketValid(XtAppContext appContext)
{
	Boolean valid = FALSE;
	krb5_error_code error;
	krb5_context ctx;
	krb5_ccache ccache;
	krb5_principal principal;
	krb5_creds pattern;
	krb5_creds creds;
	krb5_realm *realm;
	Boolean expired;
	Boolean needs_renewing;
	time_t now;
	char *principal_name;


	if ((error = krb5_init_context(&ctx)) != 0) {
	    warn(appContext, "krb5_init_context", error);
	    snprintf(credinfo, sizeof credinfo, "kerberos not available");
	    return FALSE;
	}
	if ((error = krb5_cc_default(ctx, &ccache)) != 0) {
	    warn(appContext, "krb5_cc_default", error);
	    krb5_free_context(ctx);
	    snprintf(credinfo, sizeof credinfo, "no credential cache");
	    return FALSE;
	}
	if ((error = krb5_cc_get_principal(ctx, ccache, &principal)) != 0) {
	    warn(appContext, "krb5_cc_get_principal", error);
	    krb5_cc_close(ctx, ccache);
	    krb5_free_context(ctx);
	    snprintf(credinfo, sizeof credinfo, "no credentials");
	    return FALSE;
	}
	realm = krb5_princ_realm(ctx, principal);
	memset(&pattern, 0, sizeof pattern);
	if ((error = krb5_make_principal(ctx, &pattern.server,
		*realm, KRB5_TGS_NAME, *realm, NULL)) != 0) {
	    warn(appContext, "krb5_make_principal", error);
	    krb5_free_principal(ctx, principal);
	    krb5_cc_close(ctx, ccache);
	    krb5_free_context(ctx);
	    snprintf(credinfo, sizeof credinfo, "internal error");
	    return FALSE;
	}
	if ((error = krb5_cc_retrieve_cred(ctx, ccache, 0, &pattern, 
		&creds)) != 0) {
	    warn(appContext, "krb5_cc_retreive_cred", error);
	    krb5_free_principal(ctx, pattern.server);
	    krb5_free_principal(ctx, principal);
	    krb5_cc_close(ctx, ccache);
	    krb5_free_context(ctx);
	    snprintf(credinfo, sizeof credinfo, "cannot read credentials");
	    return FALSE;
	}
	now = time(NULL);

	expired = creds.times.endtime < now;
	needs_renewing = creds.times.endtime < now + renew_remaining 
		&& creds.times.renew_till > now;

	if (krb5_unparse_name(ctx, principal, &principal_name) != 0)
	    principal_name = NULL;

	if (debug) {
	    fprintf(stderr, "expires in %d secs, renewable for %d secs\n",
		creds.times.endtime - now,
		creds.times.renew_till - now);
	}

	{
	    int exph, expm, renh, renm;
	    time_t exp = creds.times.endtime - now;
	    time_t ren = creds.times.renew_till - now;
	    char expt[32], rent[32];
	    struct tm exptm, rentm;

	    localtime_r(&creds.times.endtime, &exptm);
	    localtime_r(&creds.times.renew_till, &rentm);

	    strftime(expt, sizeof expt, "%a %X", &exptm);
	    strftime(rent, sizeof rent, "%a %X", &rentm);

#define MINUTE 60
#define HOUR (60*MINUTE)

	    if (exp < 0) {
		exph = exp / HOUR; expm = (-exp / MINUTE) % 60;
	    } else {
		exph = exp / HOUR; expm = (exp / MINUTE) % 60;
	    }

	    if (ren < 0) {
		renh = ren / HOUR; renm = (-ren / MINUTE) % 60;
	    } else {
		renh = ren / HOUR; renm = (ren / MINUTE) % 60;
	    }

	    snprintf(credinfo, sizeof credinfo,
		"%s\n"
		"expires %s (%dh%02um)\n"
		"renewable until %s (%dh%02um)",
		principal_name ? principal_name : "unknown principal",
		expt, exph, expm,
		rent, renh, renm);
	}

	if (principal_name) free(principal_name);
	krb5_free_creds_contents(ctx, &creds);
	krb5_free_principal(ctx, pattern.server);
	krb5_free_principal(ctx, principal);
	krb5_cc_close(ctx, ccache);
	krb5_free_context(ctx);

	if (needs_renewing)
		KRenewTicket(appContext);

	return expired ? FALSE : TRUE;
}

void
KRenewTicket(XtAppContext appContext)
{
	if (debug) {
	    fprintf(stderr, "executing '%s'\n", renewCommand);
	}
	system(renewCommand);
}

String
KTicketGetInfo(XtAppContext appContext)
{
	return credinfo;
}

