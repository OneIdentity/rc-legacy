
Boolean KIsTicketValid(XtAppContext);
void    KRenewTicket(XtAppContext);
String  KTicketGetInfo(XtAppContext);

#define DEFAULT_CHECK_INTERVAL	5	/* seconds */

